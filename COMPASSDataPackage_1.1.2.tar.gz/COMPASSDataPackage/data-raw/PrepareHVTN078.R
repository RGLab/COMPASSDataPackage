library(preprocessData)
library(data.table)
library(COMPASS)
HVTN078<-readRDS("../inst/extdata/HVTN078_PUBID.rds")
key<-readRDS("../inst/extdata/key_HVTN078.rds")
head(HVTN078$data$meta)
HVTN078$data$individual_id<-"PUBID"
meta<-merge(HVTN078$data$meta,key,by.x="Ptid",by.y="orig",all.x=TRUE)
setnames(meta,"new","PUBID")
meta<-subset(meta,select=setdiff(colnames(meta),c("Ptid","pub_id","PTID")))
HVTN078$data$meta<-meta

#' HVTN078 COMPASS results
#' 
#' The COMPASS results for the HVTN078 presented in the COMPASS manuscript.
#' @name HVTN078
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format A COMPASSResult fotr the HVTN078 data set.
#' @source HVTN
#' @keywords HVTN COMPASS
NULL