#RV144Correlates has the correlate data.
library(RV144Correlates)
#compass model fit from correlates package
data("rv144",package = "RV144Correlates")
luminex = readRDS("../inst/extdata/Luminex.rds")
meta = rv144$data$meta
meta$PTID=as.character(meta$PTID)
rv144$data$meta = merge(meta,luminex,by="PTID")
rv144=rv144
rv144$orig <- NULL

#' RV144 Case Control data
#' 
#' This object contains the RV144 COMPASS results, primary data and metadata presented in the COMPASS paper.
#' @name rv144
#' @aliases RV144CaseControl
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format a COMPASSResult object
#' @source Based on ICS data from the HVTN and correlates provided by the HVTN.
#' @keywords RV144 primary COMPASS
NULL
