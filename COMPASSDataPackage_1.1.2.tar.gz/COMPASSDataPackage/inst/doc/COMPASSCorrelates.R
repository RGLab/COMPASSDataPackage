## ------------------------------------------------------------------------
suppressPackageStartupMessages({
	library(osDesign)
	library(COMPASS)
	library(grid)
	library(Kmisc)
	library(ggplot2)
	library(knitr)
	})
load("../data/rv144.rda")
mydata = na.omit(rv144$data$meta)

## ----include=FALSE-------------------------------------------------------
p = plot(rv144,"infect")

## ----eval=FALSE,echo=TRUE------------------------------------------------
#  p = plot(rv144,"infect")

## ----fig.width=8,echo=FALSE----------------------------------------------
grid.draw(p)

## ----PFS,fig.width=4-----------------------------------------------------
ggplot(na.omit(rv144$data$meta))+geom_boxplot()+geom_jitter()+aes(x=infect,y=PFS)+scale_y_continuous("Polyfunctionality Score")+ggtitle("Polyfunctionality Score vs. Infection")
with(na.omit(rv144$data$meta),wilcox.test(PFS~factor(infect)))

## ----FS,fig.width=4------------------------------------------------------
ggplot(na.omit(rv144$data$meta))+geom_boxplot()+geom_jitter()+aes(x=infect,y=FS)+scale_y_continuous("Functionality Score")+ggtitle("Functionality Score vs. Infection")
with(na.omit(rv144$data$meta),wilcox.test(FS~factor(infect)))

## ----V2prim,fig.width=4--------------------------------------------------
ggplot(na.omit(rv144$data$meta))+geom_boxplot()+geom_jitter()+aes(x=infect,y=V2prim)+scale_y_continuous("V2prim")+ggtitle("V2prim vs. Infection")

## ----IgAprim,fig.width=4-------------------------------------------------
ggplot(na.omit(rv144$data$meta))+geom_boxplot()+geom_jitter()+aes(x=infect,y=IgAprim)+scale_y_continuous("IgAprim")+ggtitle("IgAprim Score vs. Infection")

## ----luminex,fig.width=4-------------------------------------------------
ggplot(na.omit(rv144$data$meta))+geom_point()+geom_jitter()+aes(x=FS,y=Luminex)+scale_y_continuous("Luminex")+geom_smooth(method="lm")+ggtitle("Functionality Score vs. Luminex")
with(na.omit(rv144$data$meta),cor.test(FS,Luminex))

## ----V2V2,fig.width=4----------------------------------------------------
ggplot(na.omit(rv144$data$meta))+geom_point()+geom_jitter()+aes(x=FS,y=V2prim)+scale_y_continuous("V2prim")+geom_smooth(method="lm")+ggtitle("Functionality Score vs. V2prim")
with(na.omit(rv144$data$meta),cor.test(FS,V2prim))

## ----results='asis',include=FALSE,eval=FALSE-----------------------------
#  ##### regression for FS
#  mydata$sFS = scale(mydata$FS)
#  mydata$sPFS = scale(mydata$PFS)
#  
#  
#  I <- dim(rv144$data$n_s)[1]
#  K <- dim(rv144$data$n_s)[2]
#  T <- dim(rv144$fit$alpha_s)[1]
#  K1 <- K-1
#  M <- dim(rv144$data$categories)[2]-1
#  
#  
#  p_value <- NULL
#  pnames<-NULL
#  
#  fit.tps <- try(tps(flrstatus ~ sFS + IgAprim + sex + risk.medium + risk.high,nn0=nn0, nn1=nn1,group=mydata$stratuminds,method="PL",cohort=TRUE,data=mydata),silent=TRUE)
#  x<-t(sapply(1:length(fit.tps$coef), function(i) {
#  	as.matrix(cbind(
#  	fit.tps$coef[i],
#  	round(exp(fit.tps$coef[i]), 5),
#  	round(exp(
#  	fit.tps$coef[i] - sqrt(fit.tps$covm[i, i]) * 1.96
#  	), 3),
#  	round(exp(
#  	fit.tps$coef[i] + sqrt(fit.tps$covm[i, i]) * 1.96
#  	), 3),
#  	round(min(2 * (1 - pnorm(
#  	abs(fit.tps$coef[i] / sqrt(fit.tps$covm[i, i]))
#  	)), 1.0), 4)
#  	))
#  	}))
#  colnames(x)<-c("Coef","OR","CI.low","CI.up","p-value")
#  rownames(x)=names(fit.tps$coef)
#  kable(x)

## ----include=FALSE,eval=FALSE--------------------------------------------
#  
#  ######## regression for PFS
#  fit.tps <- try(tps(flrstatus ~   sPFS +IgAprim+ sex + risk.medium + risk.high,nn0=nn0, nn1=nn1,group=mydata$stratuminds,method="PL",cohort=TRUE,data=mydata),silent=TRUE)
#  x<-t(sapply(1:length(fit.tps$coef), function(i) {
#  	as.matrix(cbind(
#  	fit.tps$coef[i],
#  	round(exp(fit.tps$coef[i]), 5),
#  	round(exp(
#  	fit.tps$coef[i] - sqrt(fit.tps$covm[i, i]) * 1.96
#  	), 3),
#  	round(exp(
#  	fit.tps$coef[i] + sqrt(fit.tps$covm[i, i]) * 1.96
#  	), 3),
#  	round(min(2 * (1 - pnorm(
#  	abs(fit.tps$coef[i] / sqrt(fit.tps$covm[i, i]))
#  	)), 1.0), 4)
#  	))
#  	}))
#  colnames(x)<-c("Coef","OR","CI.low","CI.up","p-value")
#  rownames(x)=names(fit.tps$coef)
#  kable(x)
#  

## ---- results='asis',include=FALSE,eval=FALSE----------------------------
#  #########Individual Categories
#  dM = which(colSums(rv144$fit$mean_gamma[,1:K1])>0)
#  Mgamma <- rv144$fit$mean_gamma
#  
#  Cnames <- colnames(rv144$data$categories)[1:M]
#  pnames=NULL
#  results =NULL
#  for ( k in dM){
#    temp =Cnames[which(rv144$data$categories[k,1:M]==1)]
#    #html(h3(paste0(temp,'+',sep="", collapse="")))
#    outcome1 = unname(Mgamma[as.character(mydata$PTID),k])
#    outcome = scale(outcome1)
#    fit.tps <- try(tps(flrstatus ~ outcome + IgAprim + sex + risk.medium + risk.high,nn0=nn0, nn1=nn1,group=mydata$stratuminds,method="PL",cohort=TRUE,data=mydata),silent=TRUE)
#    x <- as.matrix(cbind(fit.tps$coef[2],round(exp(fit.tps$coef[2]),3),round(exp(fit.tps$coef[2] - sqrt(fit.tps$covm[2,2])*1.96),3),
#                         round(exp(fit.tps$coef[2] + sqrt(fit.tps$covm[2,2])*1.96),3),round(min(2*(1-pnorm(abs(fit.tps$coef[2]/sqrt(fit.tps$covm[2,2])))),1.0),4)))
#    p_value <- c(p_value, x[,5])
#    pnames <- c(pnames, paste0(temp,'+',sep="", collapse=""))
#    colnames(x)<-c("Coef","OR","CI.low","CI.up","p-value")
#    results = rbind(results,x);
#  }
#  rownames(results)=pnames
#  kable(results)

## ----results='asis',include=FALSE,eval=FALSE-----------------------------
#  
#  I <- dim(rv144$data$n_s)[1]
#  K <- dim(rv144$data$n_s)[2]
#  T <- dim(rv144$fit$alpha_s)[1]
#  K1 <- K-1
#  M <- dim(rv144$data$categories)[2]-1
#  
#  
#  p_value <- NULL
#  pnames<-NULL
#  
#  fit.tps <- try(tps(flrstatus ~ V2prim + IgAprim + sex + risk.medium + risk.high,nn0=nn0, nn1=nn1,group=mydata$stratuminds,method="PL",cohort=TRUE,data=mydata),silent=TRUE)
#  x<-t(sapply(1:length(fit.tps$coef), function(i) {
#  	as.matrix(cbind(
#  	fit.tps$coef[i],
#  	round(exp(fit.tps$coef[i]), 5),
#  	round(exp(
#  	fit.tps$coef[i] - sqrt(fit.tps$covm[i, i]) * 1.96
#  	), 3),
#  	round(exp(
#  	fit.tps$coef[i] + sqrt(fit.tps$covm[i, i]) * 1.96
#  	), 3),
#  	round(min(2 * (1 - pnorm(
#  	abs(fit.tps$coef[i] / sqrt(fit.tps$covm[i, i]))
#  	)), 1.0), 4)
#  	))
#  	}))
#  colnames(x)<-c("Coef","OR","CI.low","CI.up","p-value")
#  rownames(x)=names(fit.tps$coef)
#  kable(x)

