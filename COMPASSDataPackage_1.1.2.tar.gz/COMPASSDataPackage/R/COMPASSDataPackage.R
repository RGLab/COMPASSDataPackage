

#' Results presented in the COMPASS manuscript. 
#' 
#' The COMPASS results for the HVTN078, TB study, and RV144 study presented in the Nature Biotech paper.
#' @name COMPASSDataPackage
#' @aliases COMPASSDataPackage-package
#' @docType package
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format COMPASSResult objects for the TB, RV144, and HVTN078 studies.
#' @keywords HVTN COMPASS TB RV144 polyfunctionality single-cell antigen-specific T-cells
#' @import COMPASS
NULL
NULL


#' HVTN078 COMPASS results
#' 
#' The COMPASS results for the HVTN078 presented in the COMPASS manuscript.
#' @name HVTN078
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format A COMPASSResult fotr the HVTN078 data set.
#' @source HVTN
#' @keywords HVTN COMPASS
NULL
NULL


#' RV144 Case Control data
#' 
#' This object contains the RV144 COMPASS results, primary data and metadata presented in the COMPASS paper.
#' @name rv144
#' @aliases RV144CaseControl
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format a COMPASSResult object
#' @source Based on ICS data from the HVTN and correlates provided by the HVTN.
#' @keywords RV144 primary COMPASS
NULL
NULL


#' TB Study data for MTB specific antigens
#' 
#' The COMPASS results for the TB specific antigens presented in the COMPASS manuscript.
#' @name TB_s
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format A COMPASSResult fotr the TB specific antigens.
#' @source Chetan Seshadri and Tom Scriba.
#' @keywords TB primary COMPASS
NULL
NULL


#' TB Study data for MTB non-specific antigens
#' 
#' The COMPASS results for the TB non-specific antigens presented in the COMPASS manuscript.
#' @name TB_u
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format A COMPASSResult fotr the TB non-specific antigens.
#' @source Chetan Seshadri and Tom Scriba.
#' @keywords TB primary COMPASS
NULL
NULL
