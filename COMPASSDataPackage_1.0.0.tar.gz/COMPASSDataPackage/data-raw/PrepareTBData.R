library(preprocessData)
library(data.table)
library(COMPASS)
library(xlsx)
#datapackage.skeleton("TB")
#COMPASS results
TB_s <- readRDS("../inst/extdata/TBs_PUBID.rds")
TB_u <- readRDS("../inst/extdata/TBu_PUBID.rds")

TB_de_ID<-data.table(readRDS("../inst/extdata/key_TBs.rds"))
# Add correlates
QFT1 <- read.xlsx("../../../../Correlates/ACS donors data.xlsx",1)
QFT1<-merge(QFT1,TB_de_ID,by.x="UniqueStudyNumber",by.y="orig",all=TRUE)
meta <- as.data.frame(TB_s$data$meta)
meta <- merge(meta, QFT1, by.x="PATIENT.ID", by.y = "new", all.x=TRUE)
meta$TB <- as.factor(meta$QuantiferonInTubeResult)
meta$QFT <- meta$`D0.QFT.Ag.Nil.result`

## Remove SAC stuff
meta <- meta[grep("^SAC", meta$PATIENT.ID, inver=TRUE), ]
TB_s$data$meta<-meta


#Now TB_u
TB_de_ID<-data.table(readRDS("../inst/extdata/key_TBu.rds"))
# Add correlates
QFT1 <- read.xlsx("../../../../Correlates/ACS donors data.xlsx",1)
QFT1<-merge(QFT1,TB_de_ID,by.x="UniqueStudyNumber",by.y="orig",all=TRUE)
meta <- as.data.frame(TB_u$data$meta)
meta <- merge(meta, QFT1, by.x="PATIENT.ID", by.y = "new", all.x=TRUE)
meta$TB <- as.factor(meta$QuantiferonInTubeResult)
meta$QFT <- meta$`D0.QFT.Ag.Nil.result`

## Remove SAC stuff
meta <- meta[grep("^SAC", meta$PATIENT.ID, inver=TRUE), ]
TB_u$data$meta<-meta

#' TB Study data for MTB specific antigens
#' 
#' The COMPASS results for the TB specific antigens presented in the COMPASS manuscript.
#' @name TB_s
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format A COMPASSResult fotr the TB specific antigens.
#' @source Chetan Seshadri and Tom Scriba.
#' @keywords TB primary COMPASS
NULL

#' TB Study data for MTB non-specific antigens
#' 
#' The COMPASS results for the TB non-specific antigens presented in the COMPASS manuscript.
#' @name TB_u
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format A COMPASSResult fotr the TB non-specific antigens.
#' @source Chetan Seshadri and Tom Scriba.
#' @keywords TB primary COMPASS
NULL