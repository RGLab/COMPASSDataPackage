library(preprocessData)
library(data.table)
library(COMPASS)

#COMPASS results
rv144<-readRDS("../inst/extdata/RV144_PUBID.rds")

#FS
rv144_FS<-FunctionalityScore(rv144)
rv144_FS<-data.table(PUBID=names(rv144_FS),COMPASSFunctionalityScore=rv144_FS)

#PFS
rv144_PFS<-PolyfunctionalityScore(rv144)
rv144_PFS<-data.table(PUBID=names(rv144_PFS),COMPASSPolyfunctionalityScore=rv144_PFS)

#De-identification
rv144_de_ID<-data.table(readRDS("../../../../Submission/New Version/key_RV144.Rds"))
setnames(rv144_de_ID,c("PTID","PUBID"))
rv144_pin_ptid_map<-data.table(fread("../../../../rawData/RV144/PTID_map_case_control.csv"))
rv144_pin_ptid_map<-rv144_pin_ptid_map[,-1,with=FALSE]
setnames(rv144_pin_ptid_map,c("PTID","pin"))

#Merge the COMPASS scores
setkey(rv144_PFS,PUBID)
setkey(rv144_FS,PUBID)
rv144_COMPASS_Scores<-merge(rv144_PFS,rv144_FS)

#Merge de-identification with pin for the COMPASS scores
setkey(rv144_de_ID,PUBID)
setkey(rv144_COMPASS_Scores,PUBID)
rv144_COMPASS_Scores<-merge(rv144_de_ID,rv144_COMPASS_Scores)

rv144_pin_ptid_map<-unique(rv144_pin_ptid_map)
setkey(rv144_pin_ptid_map,PTID)
setkey(rv144_COMPASS_Scores,PTID)

rv144_COMPASS_Scores<-merge(rv144_pin_ptid_map,rv144_COMPASS_Scores)

#Correlates
rv144_primary<-data.table(fread("../inst/extdata/rv144_data_wk26_correlates_primary_scaled_single_imp.csv"))
rv144_master<-data.table(fread("../inst/extdata/rv144_master_wk26.csv"))

#Merge with rv144_master and primary
rv144_COMPASS_Scores$pin<-as.integer(rv144_COMPASS_Scores$pin)
setkey(rv144_COMPASS_Scores,pin)
setkey(rv144_master,pin)
setkey(rv144_primary,pin)

#Merge primary, master and scores
correlates_data<-merge(merge(rv144_master,rv144_COMPASS_Scores,all=FALSE),
                                   rv144_primary,all=TRUE)
correlates_data$stratuminds <- ifelse(correlates_data$dem_sex=="Female" & correlates_data$perprot=="Yes" & correlates_data$vaccno==4,1,
                                    ifelse(correlates_data$dem_sex=="Male" & correlates_data$perprot=="Yes" & correlates_data$vaccno==4,2,
                                        ifelse(correlates_data$dem_sex=="Female" & correlates_data$perprot=="No" & correlates_data$vaccno==4,3,
                                            ifelse(correlates_data$dem_sex=="Male" & correlates_data$perprot=="No" & correlates_data$vaccno==4,4,5))))
correlates_data$sex <- ifelse(correlates_data$dem_sex=="Female",1,0)

correlates_data$risk.cat <- ifelse(correlates_data$BRA_risk=="Low",0,
                                   ifelse(correlates_data$BRA_risk=="Medium",1,2)) 
correlates_data$risk.medium <- ifelse(correlates_data$BRA_risk=="Medium",1,0)
correlates_data$risk.high <- ifelse(correlates_data$BRA_risk=="High",1,0)
correlates_data$IgAprim  <- correlates_data$primary_iga_score_tomaras_wk26

correlates_data$V2prim <- correlates_data$primary_v2_gp70_v1v2_zollapazner_wk26
correlates_data$flrstatus <- ifelse(correlates_data$infect=="Yes",1,0)

# Define phase I strata, excluded the empty 6th stratum: Male/no/<4
# nn0: vector indicating the number of controls for each of the 5 Phase I strata
nn0 <- c(length(correlates_data$pin[correlates_data$infect=="No" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Female" & correlates_data$perprot=="Yes" & correlates_data$vaccno==4]),
         length(correlates_data$pin[correlates_data$infect=="No" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Male" & correlates_data$perprot=="Yes" & correlates_data$vaccno==4]),
         length(correlates_data$pin[correlates_data$infect=="No" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Female" & correlates_data$perprot=="No" & correlates_data$vaccno==4]),
         length(correlates_data$pin[correlates_data$infect=="No" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Male" & correlates_data$perprot=="No" & correlates_data$vaccno==4]),
         length(correlates_data$pin[correlates_data$infect=="No" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Female" & correlates_data$perprot=="No" & correlates_data$vaccno<4]))

# nn1: vector indicating the number of cases for each of the 5 Phase I strata
nn1 <- c(length(correlates_data$pin[correlates_data$infect=="Yes" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Female" & correlates_data$perprot=="Yes" & correlates_data$vaccno==4]),
         length(correlates_data$pin[correlates_data$infect=="Yes" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Male" & correlates_data$perprot=="Yes" & correlates_data$vaccno==4]),
         length(correlates_data$pin[correlates_data$infect=="Yes" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Female" & correlates_data$perprot=="No" & correlates_data$vaccno==4]),
         length(correlates_data$pin[correlates_data$infect=="Yes" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Male" & correlates_data$perprot=="No" & correlates_data$vaccno==4]),
         length(correlates_data$pin[correlates_data$infect=="Yes" & correlates_data$cc_cohort==1 & correlates_data$trt=="VACCINE" & correlates_data$dem_sex=="Female" & correlates_data$perprot=="No" & correlates_data$vaccno<4]))

#Select key variables from the above correlates data
subVar <- c("flrstatus","IgAprim", "V2prim", "sex", "risk.medium", "risk.high",
            "stratuminds","pin","PUBID","PTID")

rv144_correlates <- correlates_data[,which(colnames(correlates_data) %in% subVar),
                                    with = F]

###Luminex
Luminex <- readRDS("../inst/extdata/Luminex.rds")
setkey(Luminex, PTID)
setkey(rv144_correlates, PTID)
rv144_correlates <- merge(rv144_correlates, Luminex)

### Put all correlates into COMPASS result
meta <- rv144$data$meta
colnames(meta)[1] <- "PUBID"
meta <- data.table(meta)

setkey(meta,PUBID)
setkey(rv144_correlates, PUBID)
meta <- merge(meta,rv144_correlates)
meta <- data.frame(meta)
sub <- which(colnames(meta) %in% c("PTID","pin"))
include <- 1:ncol(meta)
include <- include[-sub]
meta <- meta[,include]
rv144$data$meta <- meta
rv144$data$individual_id<-"PUBID"

#' RV144 Case Control data
#' 
#' This object contains the RV144 COMPASS results, primary data and metadata presented in the COMPASS paper.
#' @name rv144
#' @aliases RV144CaseControl
#' @docType data
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format a COMPASSResult object
#' @source Based on ICS data from the HVTN and correlates provided by the HVTN.
#' @keywords RV144 primary COMPASS
NULL
