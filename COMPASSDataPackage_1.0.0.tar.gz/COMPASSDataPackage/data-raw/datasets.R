sys.source('PrepareRV144CCData.R',envir=topenv())
sys.source('PrepareTBData.R',envir=topenv())
sys.source('PrepareHVTN078.R',envir=topenv())

keepDataObjects(c("TB_u","TB_s","rv144","HVTN078"))

#' Results presented in the COMPASS manuscript. 
#' 
#' The COMPASS results for the HVTN078, TB study, and RV144 study presented in the Nature Biotech paper.
#' @name COMPASSDataPackage
#' @aliases COMPASSDataPackage-package
#' @docType package
#' @author Greg Finak \email{ gfinak at fhcrc.org }
#' @references \url{}
#' @format COMPASSResult objects for the TB, RV144, and HVTN078 studies.
#' @keywords HVTN COMPASS TB RV144 polyfunctionality single-cell antigen-specific T-cells
#' @import COMPASS
NULL
